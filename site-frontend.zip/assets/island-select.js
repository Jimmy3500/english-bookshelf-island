/* Offline Select adaptation of Animal Island UI (MIT).
 * The hidden native control retains the application's existing change handlers.
 */
(() => {
  'use strict';
  if (typeof MutationObserver === 'undefined') return;

  const instances = new Map();
  let sequence = 0;
  let opened = null;
  let observing = false;
  let layoutFrame = 0;
  const root = document.getElementById('view') || document.body;
  const clamp = (n, low, high) => Math.max(low, Math.min(n, Math.max(low, high)));
  const watch = () => observer.observe(root, {
    childList: true, subtree: true, characterData: true,
    attributes: true, attributeFilter: ['disabled', 'selected', 'label'],
  });

  class IslandSelect {
    constructor(native) {
      this.native = native;
      this.number = ++sequence;
      this.baseId = native.id || `island-select-${this.number}`;
      this.listId = `${this.baseId}-listbox`;
      this.activeIndex = -1;
      this.signature = '';
      const labels = Array.from(native.labels || []);

      this.wrapper = document.createElement('span');
      this.wrapper.className = 'island-select';
      native.before(this.wrapper);
      this.wrapper.append(native);
      native.hidden = true;
      native.tabIndex = -1;
      native.classList.add('island-select-native');
      native.dataset.islandSelect = 'true';

      this.trigger = document.createElement('button');
      this.trigger.type = 'button';
      this.trigger.id = `${this.baseId}-trigger`;
      this.trigger.className = 'island-select-trigger';
      this.trigger.setAttribute('role', 'combobox');
      this.trigger.setAttribute('aria-haspopup', 'listbox');
      this.trigger.setAttribute('aria-expanded', 'false');
      this.valueNode = document.createElement('span');
      this.valueNode.className = 'island-select-value';
      const arrow = document.createElement('span');
      arrow.className = 'island-select-arrow';
      arrow.setAttribute('aria-hidden', 'true');
      // Original arrow geometry from the upstream Select component.
      arrow.innerHTML = '<svg width="12" height="12" viewBox="0 0 12 12" fill="none"><path d="M3 4.5L6 7.5L9 4.5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>';
      this.trigger.append(this.valueNode, arrow);
      this.wrapper.append(this.trigger);

      const labelledBy = native.getAttribute('aria-labelledby');
      const explicitLabel = native.getAttribute('aria-label');
      if (labelledBy) this.trigger.setAttribute('aria-labelledby', labelledBy);
      else if (explicitLabel) this.trigger.setAttribute('aria-label', explicitLabel);
      else if (labels.length) {
        this.trigger.setAttribute('aria-labelledby', labels.map((label, index) => {
          if (!label.id) label.id = `${this.baseId}-label-${index}`;
          return label.id;
        }).join(' '));
      } else this.trigger.setAttribute('aria-label', native.title || '请选择');
      for (const label of labels) {
        label.htmlFor = this.trigger.id;
        label.classList.add('island-field');
      }
      this.trigger.title = native.title || '';
      this.onClick = () => this.isOpen ? this.close() : this.open();
      this.onKeyDown = event => this.keyDown(event);
      this.onChange = () => this.refresh();
      this.trigger.addEventListener('click', this.onClick);
      this.trigger.addEventListener('keydown', this.onKeyDown);
      native.addEventListener('change', this.onChange);
      this.refresh();
    }

    get isOpen() { return opened === this; }
    isDisabled(option) {
      return option.disabled || (option.parentElement?.tagName === 'OPTGROUP' && option.parentElement.disabled);
    }
    refresh() {
      const options = Array.from(this.native.options);
      const signature = JSON.stringify(options.map(option => [option.value, option.label, this.isDisabled(option)]));
      const selected = options[this.native.selectedIndex];
      const label = selected?.label || this.native.getAttribute('data-placeholder') || '请选择';
      if (this.valueNode.textContent !== label) this.valueNode.textContent = label;
      this.trigger.title = this.native.title ? `${this.native.title}：${label}` : label;
      this.trigger.disabled = this.native.disabled;
      this.trigger.setAttribute('aria-disabled', String(this.native.disabled));
      this.wrapper.classList.toggle('is-disabled', this.native.disabled);
      if (this.native.disabled && this.isOpen) this.close();
      const changed = signature !== this.signature || this.selectedValue !== this.native.value;
      this.signature = signature;
      this.selectedValue = this.native.value;
      this.options = options;
      if (this.isOpen && changed) {
        this.activeIndex = this.initialIndex();
        this.renderOptions();
        this.position();
        this.ensureActiveVisible();
      }
    }
    initialIndex() {
      const selected = this.native.selectedIndex;
      if (selected >= 0 && !this.isDisabled(this.options[selected])) return selected;
      return this.options.findIndex(option => !this.isDisabled(option));
    }
    open() {
      if (this.native.disabled || !this.native.isConnected) return;
      opened?.close();
      this.refresh();
      opened = this;
      this.activeIndex = this.initialIndex();
      this.wrapper.classList.add('is-open');
      this.trigger.setAttribute('aria-expanded', 'true');
      this.trigger.setAttribute('aria-controls', this.listId);
      this.dropdown = document.createElement('div');
      this.dropdown.id = this.listId;
      this.dropdown.className = 'island-select-dropdown island-select-viewport';
      this.dropdown.setAttribute('role', 'listbox');
      this.dropdown.tabIndex = -1;
      for (const attribute of ['aria-label', 'aria-labelledby']) {
        const value = this.trigger.getAttribute(attribute);
        if (value) this.dropdown.setAttribute(attribute, value);
      }
      this.dropdown.addEventListener('mousedown', event => event.preventDefault());
      document.body.append(this.dropdown);
      this.renderOptions();
      this.position();
      this.ensureActiveVisible();
      this.trigger.focus({ preventScroll: true });
    }
    close(restoreFocus = false) {
      if (opened === this) opened = null;
      this.wrapper.classList.remove('is-open');
      this.trigger.setAttribute('aria-expanded', 'false');
      this.trigger.removeAttribute('aria-controls');
      this.trigger.removeAttribute('aria-activedescendant');
      this.dropdown?.remove();
      this.dropdown = null;
      if (restoreFocus && this.trigger.isConnected) this.trigger.focus({ preventScroll: true });
    }
    renderOptions() {
      if (!this.dropdown) return;
      this.dropdown.replaceChildren();
      this.optionNodes = this.options.map((option, index) => {
        const item = document.createElement('div');
        item.id = `${this.listId}-option-${index}`;
        item.className = 'island-select-option';
        item.setAttribute('role', 'option');
        item.setAttribute('aria-selected', String(index === this.native.selectedIndex));
        item.setAttribute('aria-disabled', String(Boolean(this.isDisabled(option))));
        item.tabIndex = -1;
        item.classList.toggle('is-selected', index === this.native.selectedIndex);
        const label = document.createElement('span');
        label.className = 'island-select-option-label';
        label.textContent = option.label;
        item.append(label);
        if (index === this.native.selectedIndex) {
          const pill = document.createElement('span');
          pill.className = 'island-select-pill';
          pill.setAttribute('aria-hidden', 'true');
          item.append(pill);
        }
        item.addEventListener('mouseenter', () => {
          if (!this.isDisabled(option)) this.setActive(index, false);
        });
        item.addEventListener('click', () => this.choose(index));
        this.dropdown.append(item);
        return item;
      });
      if (!this.options.length) {
        const empty = document.createElement('div');
        empty.className = 'island-select-option';
        empty.setAttribute('role', 'option');
        empty.setAttribute('aria-disabled', 'true');
        empty.setAttribute('aria-selected', 'false');
        empty.textContent = '暂无选项';
        this.dropdown.append(empty);
      }
      this.setActive(this.activeIndex, false);
    }
    setActive(index, scroll = true) {
      this.activeIndex = index;
      this.optionNodes?.forEach((item, i) => item.classList.toggle('is-active', i === index));
      const active = this.optionNodes?.[index];
      if (active) {
        this.trigger.setAttribute('aria-activedescendant', active.id);
        if (scroll) this.ensureActiveVisible();
      } else this.trigger.removeAttribute('aria-activedescendant');
    }
    ensureActiveVisible() {
      const item = this.optionNodes?.[this.activeIndex];
      const menu = this.dropdown;
      if (!item || !menu) return;
      const padding = 12;
      const top = item.offsetTop;
      const bottom = top + item.offsetHeight;
      if (top < menu.scrollTop + padding) menu.scrollTop = Math.max(0, top - padding);
      else if (bottom > menu.scrollTop + menu.clientHeight - padding) menu.scrollTop = Math.max(0, bottom - menu.clientHeight + padding);
    }
    choose(index) {
      const option = this.options[index];
      if (!option || this.isDisabled(option) || this.native.disabled) return;
      this.native.selectedIndex = index;
      this.close();
      this.refresh();
      this.native.dispatchEvent(new Event('change', { bubbles: true }));
      // Grade, difficulty and library filters replace the entire view on change.
      mountAll();
      const replacement = this.native.isConnected ? this : Array.from(instances.values()).find(instance => instance.baseId === this.baseId);
      replacement?.trigger.focus({ preventScroll: true });
    }
    keyDown(event) {
      if (this.native.disabled) return;
      if (!this.isOpen) {
        if (['Enter', ' ', 'ArrowDown', 'ArrowUp'].includes(event.key)) {
          event.preventDefault();
          this.open();
        }
        return;
      }
      if (event.key === 'Tab') { this.close(); return; }
      if (event.key === 'Escape') { event.preventDefault(); this.close(true); return; }
      const enabled = this.options.map((option, i) => this.isDisabled(option) ? -1 : i).filter(i => i >= 0);
      if (!enabled.length) {
        if (['ArrowDown', 'ArrowUp', 'Home', 'End', 'Enter', ' '].includes(event.key)) event.preventDefault();
        return;
      }
      if (['ArrowDown', 'ArrowUp', 'Home', 'End'].includes(event.key)) {
        event.preventDefault();
        const current = enabled.indexOf(this.activeIndex);
        const next = event.key === 'Home' ? enabled[0] : event.key === 'End' ? enabled.at(-1)
          : enabled[(current + (event.key === 'ArrowDown' ? 1 : -1) + enabled.length) % enabled.length];
        this.setActive(next);
      } else if (event.key === 'Enter' || event.key === ' ') {
        event.preventDefault();
        this.choose(this.activeIndex);
      }
    }
    position() {
      if (!this.dropdown || !this.native.isConnected) return;
      const rect = this.trigger.getBoundingClientRect();
      const viewport = window.visualViewport;
      const leftEdge = viewport?.offsetLeft || 0;
      const topEdge = viewport?.offsetTop || 0;
      const width = viewport?.width || window.innerWidth;
      const height = viewport?.height || window.innerHeight;
      const inset = 12, gap = 6;
      const availableWidth = Math.max(0, width - inset * 2);
      this.dropdown.style.position = 'fixed';
      this.dropdown.style.minWidth = `${Math.min(Math.max(160, rect.width), availableWidth)}px`;
      this.dropdown.style.maxWidth = `${Math.min(420, availableWidth)}px`;
      this.dropdown.style.maxHeight = `${Math.min(344, Math.max(0, height - inset * 2))}px`;
      this.dropdown.style.left = `${leftEdge + inset}px`;
      this.dropdown.style.top = `${topEdge + inset}px`;
      const measured = this.dropdown.getBoundingClientRect();
      const menuWidth = measured.width;
      const menuHeight = measured.height;
      const rightSpace = leftEdge + width - inset - rect.right;
      const leftSpace = rect.left - leftEdge - inset;
      let x, y, placement;
      // Upstream Select prefers a menu beside the field, reversing near an edge.
      if (rightSpace >= menuWidth + gap || leftSpace >= menuWidth + gap) {
        const right = rightSpace >= menuWidth + gap;
        x = right ? rect.right + gap : rect.left - menuWidth - gap;
        const below = topEdge + height - inset - rect.bottom;
        const above = rect.top - topEdge - inset;
        if (below < menuHeight && above > below) y = rect.top - menuHeight - gap;
        else if (below < menuHeight || above < menuHeight) y = rect.bottom + gap;
        else y = rect.top + rect.height / 2 - menuHeight / 2;
        placement = right ? 'right' : 'left';
      } else {
        x = rect.left;
        const below = topEdge + height - inset - rect.bottom - gap;
        const above = rect.top - topEdge - inset - gap;
        const goAbove = below < menuHeight && above > below;
        const room = Math.max(0, goAbove ? above : below);
        this.dropdown.style.maxHeight = `${Math.min(344, room)}px`;
        const fitted = this.dropdown.getBoundingClientRect().height;
        y = goAbove ? rect.top - fitted - gap : rect.bottom + gap;
        placement = goAbove ? 'top' : 'bottom';
      }
      const fitted = this.dropdown.getBoundingClientRect();
      this.dropdown.style.left = `${clamp(x, leftEdge + inset, leftEdge + width - fitted.width - inset)}px`;
      this.dropdown.style.top = `${clamp(y, topEdge + inset, topEdge + height - fitted.height - inset)}px`;
      this.dropdown.dataset.placement = placement;
    }
    destroy() {
      this.close();
      this.trigger.removeEventListener('click', this.onClick);
      this.trigger.removeEventListener('keydown', this.onKeyDown);
      this.native.removeEventListener('change', this.onChange);
    }
  }

  function mountAll() {
    observer.disconnect();
    for (const [native, instance] of instances) {
      if (!native.isConnected) { instance.destroy(); instances.delete(native); }
    }
    for (const native of root.querySelectorAll('select:not([multiple])')) {
      if (!instances.has(native)) instances.set(native, new IslandSelect(native));
      else instances.get(native).refresh();
    }
    watch();
    observing = true;
  }
  const observer = new MutationObserver(mountAll);
  const outside = event => {
    if (opened && !opened.wrapper.contains(event.target) && !opened.dropdown?.contains(event.target)) opened.close();
  };
  document.addEventListener('mousedown', outside);
  document.addEventListener('touchstart', outside, { passive: true });
  const reposition = event => {
    if (!opened || event?.target === opened.dropdown || layoutFrame) return;
    layoutFrame = requestAnimationFrame(() => { layoutFrame = 0; opened?.position(); });
  };
  window.addEventListener('resize', reposition);
  window.addEventListener('scroll', reposition, true);
  window.visualViewport?.addEventListener('resize', reposition);
  window.visualViewport?.addEventListener('scroll', reposition);
  window.addEventListener('hashchange', () => opened?.close());
  window.IslandSelect = Object.freeze({ mountAll, closeAll: () => opened?.close() });
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', () => { if (!observing) mountAll(); }, { once: true });
  else mountAll();
})();
