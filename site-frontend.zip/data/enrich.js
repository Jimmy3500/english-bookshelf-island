// 由 AI 补充的中文提示、词表与理解题（可选）。格式见 skill 的 README。
window.ENRICH=window.ENRICH||{};
